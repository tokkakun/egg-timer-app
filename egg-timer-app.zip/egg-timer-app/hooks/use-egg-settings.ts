import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { EggSize, EggTemperature, getCookingTime, CookingTime } from "@/lib/egg-cooking-calculator";

export interface EggSettings {
  size: EggSize;
  temperature: EggTemperature;
}

const STORAGE_KEY = "egg_settings";
const DEFAULT_SIZE: EggSize = "M";
const DEFAULT_TEMPERATURE: EggTemperature = "room";

/**
 * Custom hook to manage egg settings (size and temperature) with AsyncStorage persistence
 */
export function useEggSettings() {
  const [settings, setSettings] = useState<EggSettings>({
    size: DEFAULT_SIZE,
    temperature: DEFAULT_TEMPERATURE,
  });

  const [isLoading, setIsLoading] = useState(true);

  // Load settings from AsyncStorage on mount
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setSettings({
          size: (parsed.size as EggSize) || DEFAULT_SIZE,
          temperature: (parsed.temperature as EggTemperature) || DEFAULT_TEMPERATURE,
        });
      }
    } catch (error) {
      console.error("Failed to load egg settings:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const saveSettings = useCallback(async (newSettings: EggSettings) => {
    try {
      setSettings(newSettings);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
      return true;
    } catch (error) {
      console.error("Failed to save egg settings:", error);
      return false;
    }
  }, []);

  const updateSize = useCallback(
    (size: EggSize) => {
      return saveSettings({
        ...settings,
        size,
      });
    },
    [settings, saveSettings]
  );

  const updateTemperature = useCallback(
    (temperature: EggTemperature) => {
      return saveSettings({
        ...settings,
        temperature,
      });
    },
    [settings, saveSettings]
  );

  const resetToDefaults = useCallback(async () => {
    const defaults: EggSettings = {
      size: DEFAULT_SIZE,
      temperature: DEFAULT_TEMPERATURE,
    };
    return saveSettings(defaults);
  }, [saveSettings]);

  /**
   * Get cooking time based on current settings
   */
  const getCookingTimeForCurrentSettings = useCallback((): CookingTime => {
    return getCookingTime(settings.size, settings.temperature);
  }, [settings]);

  return {
    settings,
    isLoading,
    saveSettings,
    updateSize,
    updateTemperature,
    resetToDefaults,
    getCookingTimeForCurrentSettings,
  };
}
