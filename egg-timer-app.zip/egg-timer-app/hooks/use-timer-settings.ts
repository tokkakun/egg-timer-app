import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AlarmSoundType } from "@/lib/alarm-sounds";

// Default durations (in seconds)
const DEFAULT_HEAT_DURATION = 4 * 60; // 4 minutes
const DEFAULT_RUNNY_DURATION = 3 * 60; // 3 minutes
const DEFAULT_NORMAL_DURATION = 5 * 60; // 5 minutes
const DEFAULT_ALARM_SOUND: AlarmSoundType = "beep";

export interface TimerSettings {
  heatDuration: number; // in seconds
  runnyDuration: number; // in seconds
  normalDuration: number; // in seconds
  soundEnabled: boolean; // whether to play sound on completion
  alarmSound: AlarmSoundType; // selected alarm sound
}

const STORAGE_KEY = "egg_timer_settings";

/**
 * Custom hook to manage timer settings with AsyncStorage persistence
 */
export function useTimerSettings() {
  const [settings, setSettings] = useState<TimerSettings>({
    heatDuration: DEFAULT_HEAT_DURATION,
    runnyDuration: DEFAULT_RUNNY_DURATION,
    normalDuration: DEFAULT_NORMAL_DURATION,
    soundEnabled: true,
    alarmSound: DEFAULT_ALARM_SOUND,
  });

  const [isLoading, setIsLoading] = useState(true);

  // Load settings from AsyncStorage on mount
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = useCallback(async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setSettings({
          heatDuration: Math.max(60, Math.min(600, parsed.heatDuration || DEFAULT_HEAT_DURATION)),
          runnyDuration: Math.max(60, Math.min(600, parsed.runnyDuration || DEFAULT_RUNNY_DURATION)),
          normalDuration: Math.max(60, Math.min(600, parsed.normalDuration || DEFAULT_NORMAL_DURATION)),
          soundEnabled: parsed.soundEnabled !== undefined ? parsed.soundEnabled : true,
          alarmSound: (parsed.alarmSound as AlarmSoundType) || DEFAULT_ALARM_SOUND,
        });
      }
    } catch (error) {
      console.error("Failed to load timer settings:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const saveSettings = useCallback(async (newSettings: TimerSettings) => {
    try {
      // Validate values
      const validated: TimerSettings = {
        heatDuration: Math.max(60, Math.min(600, newSettings.heatDuration)),
        runnyDuration: Math.max(60, Math.min(600, newSettings.runnyDuration)),
        normalDuration: Math.max(60, Math.min(600, newSettings.normalDuration)),
        soundEnabled: newSettings.soundEnabled !== undefined ? newSettings.soundEnabled : true,
        alarmSound: newSettings.alarmSound || DEFAULT_ALARM_SOUND,
      };

      setSettings(validated);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(validated));
      return true;
    } catch (error) {
      console.error("Failed to save timer settings:", error);
      return false;
    }
  }, []);

  const resetToDefaults = useCallback(async () => {
    const defaults: TimerSettings = {
      heatDuration: DEFAULT_HEAT_DURATION,
      runnyDuration: DEFAULT_RUNNY_DURATION,
      normalDuration: DEFAULT_NORMAL_DURATION,
      soundEnabled: true,
      alarmSound: DEFAULT_ALARM_SOUND,
    };
    return saveSettings(defaults);
  }, [saveSettings]);

  const updateHeatDuration = useCallback(
    (duration: number) => {
      return saveSettings({
        ...settings,
        heatDuration: duration,
      });
    },
    [settings, saveSettings]
  );

  const updateRunnyDuration = useCallback(
    (duration: number) => {
      return saveSettings({
        ...settings,
        runnyDuration: duration,
      });
    },
    [settings, saveSettings]
  );

  const updateNormalDuration = useCallback(
    (duration: number) => {
      return saveSettings({
        ...settings,
        normalDuration: duration,
      });
    },
    [settings, saveSettings]
  );

  const toggleSoundEnabled = useCallback(() => {
    return saveSettings({
      ...settings,
      soundEnabled: !settings.soundEnabled,
    });
  }, [settings, saveSettings]);

  const updateAlarmSound = useCallback(
    (alarmSound: AlarmSoundType) => {
      return saveSettings({
        ...settings,
        alarmSound,
      });
    },
    [settings, saveSettings]
  );

  return {
    settings,
    isLoading,
    saveSettings,
    resetToDefaults,
    updateHeatDuration,
    updateRunnyDuration,
    updateNormalDuration,
    toggleSoundEnabled,
    updateAlarmSound,
  };
}

/**
 * Convert seconds to minutes for display
 */
export function secondsToMinutes(seconds: number): number {
  return Math.round(seconds / 60);
}

/**
 * Convert minutes to seconds for storage
 */
export function minutesToSeconds(minutes: number): number {
  return minutes * 60;
}
