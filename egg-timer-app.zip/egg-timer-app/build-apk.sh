#!/bin/bash

# APKビルド用シェルスクリプト
# このスクリプトはmacOS/Linux環境で実行してください

echo ""
echo "========================================"
echo "半熟卵タイマー APKビルドスクリプト"
echo "========================================"
echo ""

# ディレクトリ確認
if [ ! -f "app.config.ts" ]; then
    echo "エラー: このスクリプトをプロジェクトルートディレクトリで実行してください"
    exit 1
fi

# EAS CLIがインストールされているか確認
if ! command -v eas &> /dev/null; then
    echo "EAS CLIをインストール中..."
    npm install -g eas-cli
    if [ $? -ne 0 ]; then
        echo "エラー: EAS CLIのインストールに失敗しました"
        exit 1
    fi
fi

# Expoアカウントにログイン
echo ""
echo "Expoアカウントにログイン中..."
eas login
if [ $? -ne 0 ]; then
    echo "エラー: ログインに失敗しました"
    exit 1
fi

# APKビルド実行
echo ""
echo "APKビルドを開始します..."
echo "プロセスが完了するまでお待ちください（数分〜数十分かかります）"
echo ""
eas build --platform android --type apk

if [ $? -ne 0 ]; then
    echo "エラー: ビルドに失敗しました"
    exit 1
fi

echo ""
echo "========================================"
echo "ビルドが完了しました！"
echo "========================================"
echo ""
echo "APKファイルは以下のURLからダウンロードできます："
echo "https://expo.dev/accounts/[your-username]/projects/egg-timer-app/builds"
echo ""
