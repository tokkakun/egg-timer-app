import React, { useState } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  TextInput,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useTimerSettings, secondsToMinutes, minutesToSeconds } from "@/hooks/use-timer-settings";
import { useEggSettings } from "@/hooks/use-egg-settings";
import {
  EggSize,
  EggTemperature,
  getSizeLabel,
  getTemperatureLabel,
  getAvailableSizes,
  getAvailableTemperatures,
} from "@/lib/egg-cooking-calculator";
import * as Haptics from "expo-haptics";
import { getAvailableAlarmSounds, playAlarmSound } from "@/lib/alarm-sounds";

export default function SettingsScreen() {
  const colors = useColors();
  const {
    settings,
    isLoading,
    resetToDefaults,
    updateHeatDuration,
    updateRunnyDuration,
    updateNormalDuration,
    toggleSoundEnabled,
    updateAlarmSound,
  } = useTimerSettings();

  const {
    settings: eggSettings,
    isLoading: eggSettingsLoading,
    updateSize,
    updateTemperature,
  } = useEggSettings();

  const [heatMinutes, setHeatMinutes] = useState(
    String(secondsToMinutes(settings.heatDuration))
  );
  const [runnyMinutes, setRunnyMinutes] = useState(
    String(secondsToMinutes(settings.runnyDuration))
  );
  const [normalMinutes, setNormalMinutes] = useState(
    String(secondsToMinutes(settings.normalDuration))
  );
  const [saveMessage, setSaveMessage] = useState("");

  const handleSaveHeat = async () => {
    const minutes = Math.max(1, Math.min(10, parseInt(heatMinutes) || 4));
    setHeatMinutes(String(minutes));
    await updateHeatDuration(minutesToSeconds(minutes));
    setSaveMessage("加熱時間を保存しました");
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleSaveRunny = async () => {
    const minutes = Math.max(1, Math.min(10, parseInt(runnyMinutes) || 3));
    setRunnyMinutes(String(minutes));
    await updateRunnyDuration(minutesToSeconds(minutes));
    setSaveMessage("とろとろ蒸らし時間を保存しました");
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleSaveNormal = async () => {
    const minutes = Math.max(1, Math.min(10, parseInt(normalMinutes) || 5));
    setNormalMinutes(String(minutes));
    await updateNormalDuration(minutesToSeconds(minutes));
    setSaveMessage("普通蒸らし時間を保存しました");
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleReset = async () => {
    await resetToDefaults();
    setHeatMinutes(String(secondsToMinutes(settings.heatDuration)));
    setRunnyMinutes(String(secondsToMinutes(settings.runnyDuration)));
    setNormalMinutes(String(secondsToMinutes(settings.normalDuration)));
    setSaveMessage("デフォルト設定に戻しました");
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  };

  const handleSizeSelect = async (size: EggSize) => {
    await updateSize(size);
    setSaveMessage(`卵のサイズを「${getSizeLabel(size)}」に設定しました`);
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleTemperatureSelect = async (temperature: EggTemperature) => {
    await updateTemperature(temperature);
    setSaveMessage(`卵の温度を「${getTemperatureLabel(temperature)}」に設定しました`);
    setTimeout(() => setSaveMessage(""), 2000);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  if (isLoading || eggSettingsLoading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text style={{ color: colors.muted }}>読み込み中...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            ⚙️ 設定
          </Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>
            タイマー時間と卵の設定をカスタマイズ
          </Text>
        </View>

        {/* Save Message */}
        {saveMessage && (
          <View
            style={[
              styles.messageBox,
              { backgroundColor: colors.success + "22", borderColor: colors.success },
            ]}
          >
            <Text style={[styles.messageText, { color: colors.success }]}>
              ✓ {saveMessage}
            </Text>
          </View>
        )}

        {/* Egg Size Selection Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              🥚 卵のサイズ
            </Text>
            <Text style={[styles.sectionDesc, { color: colors.muted }]}>
              ゆで時間は卵のサイズで自動調整されます
            </Text>
          </View>

          <View style={styles.buttonGroup}>
            {getAvailableSizes().map((size) => (
              <Pressable
                key={size}
                onPress={() => handleSizeSelect(size)}
                style={({ pressed }) => [
                  styles.optionButton,
                  {
                    backgroundColor:
                      eggSettings.size === size
                        ? colors.primary
                        : colors.background,
                    borderColor: colors.border,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.optionButtonText,
                    {
                      color:
                        eggSettings.size === size
                          ? "#fff"
                          : colors.foreground,
                    },
                  ]}
                >
                  {getSizeLabel(size)}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Egg Temperature Selection Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              🌡️ 卵の温度
            </Text>
            <Text style={[styles.sectionDesc, { color: colors.muted }]}>
              冷蔵卵は加熱時間が長くなります
            </Text>
          </View>

          <View style={styles.buttonGroup}>
            {getAvailableTemperatures().map((temp) => (
              <Pressable
                key={temp}
                onPress={() => handleTemperatureSelect(temp)}
                style={({ pressed }) => [
                  styles.optionButton,
                  {
                    backgroundColor:
                      eggSettings.temperature === temp
                        ? colors.primary
                        : colors.background,
                    borderColor: colors.border,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.optionButtonText,
                    {
                      color:
                        eggSettings.temperature === temp
                          ? "#fff"
                          : colors.foreground,
                    },
                  ]}
                >
                  {getTemperatureLabel(temp)}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Heat Duration Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              🔥 加熱時間
            </Text>
            <Text style={[styles.sectionDesc, { color: colors.muted }]}>
              鍋底から1cmの水で中火にかける時間
            </Text>
          </View>

          <View style={styles.inputRow}>
            <TextInput
              style={[
                styles.timeInput,
                {
                  color: colors.foreground,
                  backgroundColor: colors.background,
                  borderColor: colors.border,
                },
              ]}
              placeholder="分"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              value={heatMinutes}
              onChangeText={setHeatMinutes}
              maxLength={2}
            />
            <Text style={[styles.unitText, { color: colors.muted }]}>分</Text>
            <Pressable
              onPress={handleSaveHeat}
              style={({ pressed }) => [
                styles.saveBtn,
                { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.saveBtnText}>保存</Text>
            </Pressable>
          </View>

          <View style={[styles.infoBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Text style={[styles.infoText, { color: colors.muted }]}>
              推奨: 4分 | 範囲: 1〜10分
            </Text>
          </View>
        </View>

        {/* Runny Duration Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              🥚 とろとろ蒸らし時間
            </Text>
            <Text style={[styles.sectionDesc, { color: colors.muted }]}>
              火を止めて蓋をしたまま置く時間
            </Text>
          </View>

          <View style={styles.inputRow}>
            <TextInput
              style={[
                styles.timeInput,
                {
                  color: colors.foreground,
                  backgroundColor: colors.background,
                  borderColor: colors.border,
                },
              ]}
              placeholder="分"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              value={runnyMinutes}
              onChangeText={setRunnyMinutes}
              maxLength={2}
            />
            <Text style={[styles.unitText, { color: colors.muted }]}>分</Text>
            <Pressable
              onPress={handleSaveRunny}
              style={({ pressed }) => [
                styles.saveBtn,
                { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.saveBtnText}>保存</Text>
            </Pressable>
          </View>

          <View style={[styles.infoBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Text style={[styles.infoText, { color: colors.muted }]}>
              推奨: 3分 | 範囲: 1〜10分
            </Text>
          </View>
        </View>

        {/* Normal Duration Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              🍳 普通蒸らし時間
            </Text>
            <Text style={[styles.sectionDesc, { color: colors.muted }]}>
              火を止めて蓋をしたまま置く時間
            </Text>
          </View>

          <View style={styles.inputRow}>
            <TextInput
              style={[
                styles.timeInput,
                {
                  color: colors.foreground,
                  backgroundColor: colors.background,
                  borderColor: colors.border,
                },
              ]}
              placeholder="分"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              value={normalMinutes}
              onChangeText={setNormalMinutes}
              maxLength={2}
            />
            <Text style={[styles.unitText, { color: colors.muted }]}>分</Text>
            <Pressable
              onPress={handleSaveNormal}
              style={({ pressed }) => [
                styles.saveBtn,
                { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.saveBtnText}>保存</Text>
            </Pressable>
          </View>

          <View style={[styles.infoBox, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Text style={[styles.infoText, { color: colors.muted }]}>
              推奨: 5分 | 範囲: 1〜10分
            </Text>
          </View>
        </View>

        {/* Sound Settings Section */}
        <View style={[styles.section, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.soundSettingRow}>
            <View style={styles.soundSettingLabel}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                🔊 音設定
              </Text>
              <Text style={[styles.sectionDesc, { color: colors.muted }]}>
                タイマー完了時に音を鳴らす
              </Text>
            </View>
            <Switch
              value={settings.soundEnabled}
              onValueChange={() => {
                toggleSoundEnabled();
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              trackColor={{ false: colors.border, true: colors.primary + "66" }}
              thumbColor={settings.soundEnabled ? colors.primary : colors.muted}
            />
          </View>

          {/* Alarm Sound Selection */}
          {settings.soundEnabled && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                  🎵 アラーム音を選択
                </Text>
                <Text style={[styles.sectionDesc, { color: colors.muted }]}>
                  タイマー完了時に鳴るアラーム音を選択してください
                </Text>
              </View>

              <View style={styles.alarmSoundGrid}>
                {getAvailableAlarmSounds().map((sound) => (
                  <Pressable
                    key={sound.id}
                    onPress={() => {
                      updateAlarmSound(sound.id);
                      playAlarmSound(sound.id);
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setSaveMessage(`アラーム音を「${sound.name}」に設定しました`);
                      setTimeout(() => setSaveMessage(""), 2000);
                    }}
                    style={({ pressed }) => [
                      styles.alarmSoundButton,
                      {
                        backgroundColor:
                          settings.alarmSound === sound.id
                            ? colors.primary
                            : colors.background,
                        borderColor: colors.border,
                        opacity: pressed ? 0.8 : 1,
                      },
                    ]}
                  >
                    <Text style={styles.alarmSoundEmoji}>{sound.emoji}</Text>
                    <Text
                      style={[
                        styles.alarmSoundName,
                        {
                          color:
                            settings.alarmSound === sound.id
                              ? "#fff"
                              : colors.foreground,
                        },
                      ]}
                    >
                      {sound.name}
                    </Text>
                    <Text
                      style={[
                        styles.alarmSoundDesc,
                        {
                          color:
                            settings.alarmSound === sound.id
                              ? "#fff"
                              : colors.muted,
                        },
                      ]}
                    >
                      {sound.description}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </>
          )}
        </View>

        {/* Reset Button */}
        <Pressable
          onPress={handleReset}
          style={({ pressed }) => [
            styles.resetBtn,
            {
              backgroundColor: colors.error + "22",
              borderColor: colors.error,
              opacity: pressed ? 0.7 : 1,
            },
          ]}
        >
          <Text style={[styles.resetBtnText, { color: colors.error }]}>
            🔄 デフォルト設定に戻す
          </Text>
        </Pressable>

        {/* Info Section */}
        <View style={[styles.infoSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.infoTitle, { color: colors.foreground }]}>
            💡 使い方のコツ
          </Text>
          <Text style={[styles.infoItem, { color: colors.muted }]}>
            • 卵のサイズと温度を選択すると、最適なゆで時間が自動設定されます
          </Text>
          <Text style={[styles.infoItem, { color: colors.muted }]}>
            • 加熱時間は卵の大きさや鍋の種類で調整
          </Text>
          <Text style={[styles.infoItem, { color: colors.muted }]}>
            • 蒸らし時間が短いほど黄身がとろとろ
          </Text>
          <Text style={[styles.infoItem, { color: colors.muted }]}>
            • アラーム音をクリックするとプレビューが再生されます
          </Text>
          <Text style={[styles.infoItem, { color: colors.muted }]}>
            • 設定は自動的に保存されます
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 32,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 14,
    borderBottomWidth: 1,
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    letterSpacing: 0.3,
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
  },
  messageBox: {
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  messageText: {
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },
  section: {
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  sectionHeader: {
    gap: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  sectionDesc: {
    fontSize: 13,
    lineHeight: 20,
  },
  buttonGroup: {
    flexDirection: "row",
    gap: 10,
  },
  optionButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1.5,
    alignItems: "center",
  },
  optionButtonText: {
    fontSize: 14,
    fontWeight: "600",
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  timeInput: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
  unitText: {
    fontSize: 14,
    fontWeight: "600",
    minWidth: 30,
  },
  saveBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "700",
  },
  infoBox: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  infoText: {
    fontSize: 12,
    textAlign: "center",
  },
  resetBtn: {
    marginHorizontal: 16,
    marginTop: 24,
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: "center",
  },
  resetBtnText: {
    fontSize: 15,
    fontWeight: "700",
  },
  infoSection: {
    marginHorizontal: 16,
    marginTop: 20,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 8,
    marginBottom: 20,
  },
  infoTitle: {
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 4,
  },
  infoItem: {
    fontSize: 13,
    lineHeight: 20,
  },
  soundSettingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  soundSettingLabel: {
    flex: 1,
    gap: 4,
  },
  alarmSoundGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  alarmSoundButton: {
    flex: 1,
    minWidth: "45%",
    paddingVertical: 14,
    paddingHorizontal: 10,
    borderRadius: 12,
    borderWidth: 1.5,
    alignItems: "center",
    gap: 6,
  },
  alarmSoundEmoji: {
    fontSize: 24,
  },
  alarmSoundName: {
    fontSize: 13,
    fontWeight: "700",
  },
  alarmSoundDesc: {
    fontSize: 11,
    lineHeight: 16,
    textAlign: "center",
  },
});
