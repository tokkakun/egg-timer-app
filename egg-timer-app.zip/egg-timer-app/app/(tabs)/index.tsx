import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Platform,
  Dimensions,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";
import { useKeepAwake } from "expo-keep-awake";
import { setAudioModeAsync } from "expo-audio";
import Svg, { Circle } from "react-native-svg";
import { AppState } from "react-native";
import { playBeepSound } from "@/lib/sound-player";
import { playAlarmSound } from "@/lib/alarm-sounds";

import { useTimerSettings as useTimerSettingsHook } from "@/hooks/use-timer-settings";
import { useEggSettings } from "@/hooks/use-egg-settings";
import { getCookingTime, getSizeLabel, getTemperatureLabel } from "@/lib/egg-cooking-calculator";
import { CompletionAnimation } from "@/components/completion-animation";

// ─── Types ───────────────────────────────────────────────────────────────────

type AppStep = "step1" | "step2" | "yolk_choice" | "step2b" | "step3";

// ─── Constants ───────────────────────────────────────────────────────────────

const STEP2_DURATION = 4 * 60; // 4 minutes in seconds
const YOLK_RUNNY_DURATION = 3 * 60; // 3 minutes
const YOLK_NORMAL_DURATION = 5 * 60; // 5 minutes

const SCREEN_WIDTH = Dimensions.get("window").width;
const TIMER_SIZE = Math.min(SCREEN_WIDTH * 0.72, 280);
const STROKE_WIDTH = 14;
const RADIUS = (TIMER_SIZE - STROKE_WIDTH) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function StepIndicator({ current }: { current: AppStep }) {
  const colors = useColors();
  const steps: { key: AppStep | "step2b"; label: string }[] = [
    { key: "step1", label: "① 準備" },
    { key: "step2", label: "② 加熱" },
    { key: "step2b", label: "③ 蒸らし" },
    { key: "step3", label: "④ 完成" },
  ];

  const activeIndex =
    current === "step1"
      ? 0
      : current === "step2"
      ? 1
      : current === "yolk_choice" || current === "step2b"
      ? 2
      : 3;

  return (
    <View style={styles.stepIndicatorContainer}>
      {steps.map((step, idx) => {
        const isActive = idx === activeIndex;
        const isDone = idx < activeIndex;
        return (
          <View key={step.key} style={styles.stepIndicatorItem}>
            <View
              style={[
                styles.stepDot,
                {
                  backgroundColor: isDone
                    ? colors.success
                    : isActive
                    ? colors.primary
                    : colors.border,
                },
              ]}
            >
              {isDone ? (
                <Text style={[styles.stepDotText, { color: "#fff" }]}>✓</Text>
              ) : (
                <Text
                  style={[
                    styles.stepDotText,
                    { color: isActive ? "#fff" : colors.muted },
                  ]}
                >
                  {idx + 1}
                </Text>
              )}
            </View>
            <Text
              style={[
                styles.stepLabel,
                {
                  color: isActive
                    ? colors.primary
                    : isDone
                    ? colors.success
                    : colors.muted,
                  fontWeight: isActive ? "700" : "400",
                },
              ]}
            >
              {step.label}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

function CircularTimer({
  remaining,
  total,
  isRunning,
}: {
  remaining: number;
  total: number;
  isRunning: boolean;
}) {
  const colors = useColors();
  const progress = total > 0 ? remaining / total : 0;
  const strokeDashoffset = CIRCUMFERENCE * (1 - progress);

  const trackColor = colors.border;
  const progressColor = isRunning ? colors.primary : colors.muted;

  return (
    <View style={styles.timerWrapper}>
      <Svg width={TIMER_SIZE} height={TIMER_SIZE}>
        {/* Track */}
        <Circle
          cx={TIMER_SIZE / 2}
          cy={TIMER_SIZE / 2}
          r={RADIUS}
          stroke={trackColor}
          strokeWidth={STROKE_WIDTH}
          fill="none"
        />
        {/* Progress */}
        <Circle
          cx={TIMER_SIZE / 2}
          cy={TIMER_SIZE / 2}
          r={RADIUS}
          stroke={progressColor}
          strokeWidth={STROKE_WIDTH}
          fill="none"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          rotation="-90"
          origin={`${TIMER_SIZE / 2}, ${TIMER_SIZE / 2}`}
        />
      </Svg>
      <View style={styles.timerCenter}>
        <Text style={[styles.timerText, { color: colors.foreground }]}>
          {formatTime(remaining)}
        </Text>
        <Text style={[styles.timerSubText, { color: colors.muted }]}>
          {isRunning ? "カウント中" : remaining === total ? "準備完了" : "一時停止"}
        </Text>
      </View>
    </View>
  );
}

// ─── Main Screen ─────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const colors = useColors();
  const [step, setStep] = useState<AppStep>("step1");
  // Load custom settings
  const { settings: timerSettings, isLoading: settingsLoading } = useTimerSettingsHook();
  const { settings: eggSettings, isLoading: eggSettingsLoading } = useEggSettings();
  
  const [timerDuration, setTimerDuration] = useState(timerSettings.heatDuration);
  const [remaining, setRemaining] = useState(timerSettings.heatDuration);
  const [isRunning, setIsRunning] = useState(false);
  const [showCompletionAnimation, setShowCompletionAnimation] = useState(false);
  const [appState, setAppState] = useState(AppState.currentState);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Keep screen awake when timer is running
  useKeepAwake();

  // Track app state (foreground/background)
  useEffect(() => {
    const subscription = AppState.addEventListener("change", setAppState);
    return () => {
      subscription.remove();
    };
  }, []);
  
  // Update timer duration when settings change
  React.useEffect(() => {
    if (!settingsLoading && !eggSettingsLoading) {
      // Get cooking time based on egg size and temperature
      const cookingTime = getCookingTime(eggSettings.size, eggSettings.temperature);
      setTimerDuration(cookingTime.heatDuration);
      setRemaining(cookingTime.heatDuration);
    }
  }, [timerSettings.heatDuration, eggSettings.size, eggSettings.temperature, settingsLoading, eggSettingsLoading]);

  // Audio and notification setup
  useEffect(() => {
    if (Platform.OS !== "web") {
      setAudioModeAsync({ playsInSilentMode: true }).catch(() => {});
      // Notifications disabled for Expo Go compatibility
    }
  }, []);

  // Timer logic
  const stopInterval = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const handleTimerComplete = useCallback(
    (currentStep: AppStep) => {
      stopInterval();
      setIsRunning(false);
      setShowCompletionAnimation(true);
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        // Play sound only if sound is enabled
        if (timerSettings.soundEnabled) {
          playAlarmSound(timerSettings.alarmSound);
        }
        // Send notification only if app is in background
        if (appState !== "active") {
          const notificationTitle = currentStep === "step2" ? "4分加熱完了!" : "蒸らし時間完了!";
          const notificationBody = currentStep === "step2" ? "次は仕上がりを選んでください" : "卵を冷やしたら完成です!";
        }
      } else {
        // Play sound only if sound is enabled
        if (timerSettings.soundEnabled) {
          playAlarmSound(timerSettings.alarmSound);
        }
      }
      if (currentStep === "step2") {
        setStep("yolk_choice");
      } else if (currentStep === "step2b") {
        setStep("step3");
      }
    },
    [stopInterval, timerSettings.soundEnabled, appState]
  );

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setRemaining((prev) => {
          if (prev <= 1) {
            handleTimerComplete(step);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      stopInterval();
    }
    return stopInterval;
  }, [isRunning, step, handleTimerComplete, stopInterval]);

  const startTimer = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setIsRunning(true);
  };

  const pauseTimer = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    setIsRunning(false);
  };

  const resetTimer = () => {
    stopInterval();
    setIsRunning(false);
    setRemaining(timerDuration);
  };

  const goToStep2 = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    setStep("step2");
    setTimerDuration(timerSettings.heatDuration);
    setRemaining(timerSettings.heatDuration);
    setIsRunning(false);
  };

  const chooseYolk = (runny: boolean) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    const dur = runny ? timerSettings.runnyDuration : timerSettings.normalDuration;
    setTimerDuration(dur);
    setRemaining(dur);
    setStep("step2b");
    setIsRunning(false);
  };

  const restartAll = () => {
    stopInterval();
    setStep("step1");
    setTimerDuration(STEP2_DURATION);
    setRemaining(STEP2_DURATION);
    setIsRunning(false);
  };

  // ─── Render helpers ─────────────────────────────────────────────────────

  const renderStep1 = () => (
    <View style={styles.contentCard}>
      <View style={[styles.stepIconCircle, { backgroundColor: colors.surface, borderColor: colors.primary }]}>
        <Text style={styles.stepIconEmoji}>🥚</Text>
      </View>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>
        鍋に卵をセット
      </Text>
      
      {/* Egg Settings Display */}
      <View style={[styles.eggSettingsBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <View style={styles.eggSettingRow}>
          <Text style={[styles.eggSettingLabel, { color: colors.muted }]}>卵のサイズ:</Text>
          <Text style={[styles.eggSettingValue, { color: colors.foreground }]}>
            {getSizeLabel(eggSettings.size)}
          </Text>
        </View>
        <View style={styles.eggSettingRow}>
          <Text style={[styles.eggSettingLabel, { color: colors.muted }]}>卵の温度:</Text>
          <Text style={[styles.eggSettingValue, { color: colors.foreground }]}>
            {getTemperatureLabel(eggSettings.temperature)}
          </Text>
        </View>
      </View>
      
      <Text style={[styles.cardDesc, { color: colors.muted }]}>
        鍋に卵を入れ、鍋底から{" "}
        <Text style={{ color: colors.primary, fontWeight: "700" }}>1cm</Text>{" "}
        の高さまで水を加えて{"\n"}中火にかけてください。
      </Text>
      <Text style={[styles.cardHint, { color: colors.muted, backgroundColor: colors.surface, borderColor: colors.border }]}>
        💡 水が少ないので沸騰が早いです
      </Text>
      <Pressable
        onPress={goToStep2}
        style={({ pressed }) => [
          styles.primaryBtn,
          { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <Text style={styles.primaryBtnText}>水が沸騰したら次へ →</Text>
      </Pressable>
    </View>
  );

  const renderStep2 = () => (
    <View style={styles.contentCard}>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>
        フタをして中火で加熱
      </Text>
      <Text style={[styles.cardDesc, { color: colors.muted }]}>
        フタをして{" "}
        <Text style={{ color: colors.primary, fontWeight: "700" }}>中火で{timerSettings.heatDuration}分</Text>{" "}
        加熱します。
      </Text>
      <CircularTimer
        remaining={remaining}
        total={timerDuration}
        isRunning={isRunning}
      />
      <View style={styles.timerControls}>
        {!isRunning ? (
          <Pressable
            onPress={startTimer}
            style={({ pressed }) => [
              styles.primaryBtn,
              { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Text style={styles.primaryBtnText}>
              {remaining === timerDuration ? "▶ タイマー開始" : "▶ 再開"}
            </Text>
          </Pressable>
        ) : (
          <Pressable
            onPress={pauseTimer}
            style={({ pressed }) => [
              styles.primaryBtn,
              { backgroundColor: colors.muted, opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Text style={styles.primaryBtnText}>⏸ 一時停止</Text>
          </Pressable>
        )}
        <Pressable
          onPress={resetTimer}
          style={({ pressed }) => [
            styles.secondaryBtn,
            { borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
          ]}
        >
          <Text style={[styles.secondaryBtnText, { color: colors.muted }]}>
            ↺ リセット
          </Text>
        </Pressable>
      </View>
    </View>
  );

  const renderYolkChoice = () => (
    <View style={styles.contentCard}>
      <View style={[styles.stepIconCircle, { backgroundColor: colors.surface, borderColor: colors.primary }]}>
        <Text style={styles.stepIconEmoji}>🍳</Text>
      </View>
      <Text style={[styles.cardTitle, { color: colors.foreground }]}>
        4分加熱完了！
      </Text>
      <Text style={[styles.cardDesc, { color: colors.muted }]}>
        火を止めて、蓋をしたまま置きます。{"\n"}
        黄身の仕上がりを選んでください。
      </Text>
      <View style={styles.yolkChoiceRow}>
        <Pressable
          onPress={() => chooseYolk(true)}
          style={({ pressed }) => [
            styles.yolkBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.primary,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text style={styles.yolkBtnEmoji}>🥚</Text>
          <Text style={[styles.yolkBtnTitle, { color: colors.primary }]}>
            とろとろ
          </Text>
          <Text style={[styles.yolkBtnSub, { color: colors.muted }]}>
            {Math.round(timerSettings.runnyDuration / 60)}分蒸らし
          </Text>
        </Pressable>
        <Pressable
          onPress={() => chooseYolk(false)}
          style={({ pressed }) => [
            styles.yolkBtn,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              opacity: pressed ? 0.8 : 1,
            },
          ]}
        >
          <Text style={styles.yolkBtnEmoji}>🥚</Text>
          <Text style={[styles.yolkBtnTitle, { color: colors.foreground }]}>
            普通
          </Text>
          <Text style={[styles.yolkBtnSub, { color: colors.muted }]}>
            {Math.round(timerSettings.normalDuration / 60)}分蒸らし
          </Text>
        </Pressable>
      </View>
    </View>
  );

  const renderStep2b = () => {
    const isRunny = timerDuration === YOLK_RUNNY_DURATION;
    return (
      <View style={styles.contentCard}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>
          蓋をしたまま蒸らす
        </Text>
        <Text style={[styles.cardDesc, { color: colors.muted }]}>
          火を止めて蓋をしたまま{" "}
          <Text style={{ color: colors.primary, fontWeight: "700" }}>
            {isRunny ? "3分" : "5分"}
          </Text>{" "}
          置きます。
          {isRunny ? "\n（とろとろ仕上げ）" : "\n（普通の半熟仕上げ）"}
        </Text>
        <CircularTimer
          remaining={remaining}
          total={timerDuration}
          isRunning={isRunning}
        />
        <View style={styles.timerControls}>
          {!isRunning ? (
            <Pressable
              onPress={startTimer}
              style={({ pressed }) => [
                styles.primaryBtn,
                { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.primaryBtnText}>
                {remaining === timerDuration ? "▶ タイマー開始" : "▶ 再開"}
              </Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={pauseTimer}
              style={({ pressed }) => [
                styles.primaryBtn,
                { backgroundColor: colors.muted, opacity: pressed ? 0.85 : 1 },
              ]}
            >
              <Text style={styles.primaryBtnText}>⏸ 一時停止</Text>
            </Pressable>
          )}
          <Pressable
            onPress={resetTimer}
            style={({ pressed }) => [
              styles.secondaryBtn,
              { borderColor: colors.border, opacity: pressed ? 0.7 : 1 },
            ]}
          >
            <Text style={[styles.secondaryBtnText, { color: colors.muted }]}>
              ↺ リセット
            </Text>
          </Pressable>
        </View>
      </View>
    );
  };

  const renderStep3 = () => (
    <View style={styles.contentCard}>
      <View style={[styles.completeBadge, { backgroundColor: colors.success + "22", borderColor: colors.success }]}>
        <Text style={styles.completeEmoji}>🎉</Text>
      </View>
      <Text style={[styles.cardTitle, { color: colors.success }]}>
        完成！
      </Text>
      <Text style={[styles.cardDesc, { color: colors.muted }]}>
        卵を冷水に取り出して冷やしたら{"\n"}
        <Text style={{ color: colors.foreground, fontWeight: "700" }}>
          美味しい半熟卵の完成です！
        </Text>
      </Text>
      <View style={[styles.recipeCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.recipeTitle, { color: colors.foreground }]}>
          📋 今回のレシピまとめ
        </Text>
        <Text style={[styles.recipeItem, { color: colors.muted }]}>
          ① 鍋底から1cmの水で中火にかける
        </Text>
        <Text style={[styles.recipeItem, { color: colors.muted }]}>
          ② 沸騰後フタをして4分加熱
        </Text>
        <Text style={[styles.recipeItem, { color: colors.muted }]}>
          ③ 火を止めて{timerDuration === YOLK_RUNNY_DURATION ? "3分（とろとろ）" : "5分（普通）"}蒸らす
        </Text>
        <Text style={[styles.recipeItem, { color: colors.muted }]}>
          ④ 冷水で冷やして完成
        </Text>
      </View>
      <Pressable
        onPress={restartAll}
        style={({ pressed }) => [
          styles.primaryBtn,
          { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <Text style={styles.primaryBtnText}>🔄 もう一度作る</Text>
      </Pressable>
    </View>
  );

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            🥚 半熟卵タイマー
          </Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>
            鍋底1cmの水で蒸す方法
          </Text>
        </View>

        {/* Step Indicator */}
        <StepIndicator current={step} />

        {/* Content */}
        {step === "step1" && renderStep1()}
        {step === "step2" && renderStep2()}
        {step === "yolk_choice" && renderYolkChoice()}
        {step === "step2b" && renderStep2b()}
        {step === "step3" && renderStep3()}
      </ScrollView>
      <CompletionAnimation
        isVisible={showCompletionAnimation}
        onAnimationComplete={() => setShowCompletionAnimation(false)}
      />
    </ScreenContainer>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 32,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 14,
    borderBottomWidth: 1,
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "700",
    letterSpacing: 0.3,
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
  },
  stepIndicatorContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingHorizontal: 12,
    paddingVertical: 16,
  },
  stepIndicatorItem: {
    alignItems: "center",
    gap: 6,
  },
  stepDot: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },
  stepDotText: {
    fontSize: 14,
    fontWeight: "700",
  },
  stepLabel: {
    fontSize: 11,
    textAlign: "center",
  },
  contentCard: {
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 20,
    padding: 24,
    alignItems: "center",
    gap: 16,
  },
  stepIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  stepIconEmoji: {
    fontSize: 36,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: "700",
    textAlign: "center",
    lineHeight: 30,
  },
  cardDesc: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 26,
  },
  cardHint: {
    fontSize: 13,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    textAlign: "center",
  },
  timerWrapper: {
    width: TIMER_SIZE,
    height: TIMER_SIZE,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  timerCenter: {
    position: "absolute",
    alignItems: "center",
  },
  timerText: {
    fontSize: 52,
    fontWeight: "700",
    fontVariant: ["tabular-nums"],
    letterSpacing: 2,
  },
  timerSubText: {
    fontSize: 13,
    marginTop: 4,
  },
  timerControls: {
    width: "100%",
    gap: 10,
    alignItems: "center",
  },
  primaryBtn: {
    width: "100%",
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: "center",
  },
  primaryBtnText: {
    color: "#fff",
    fontSize: 17,
    fontWeight: "700",
    letterSpacing: 0.3,
  },
  secondaryBtn: {
    width: "100%",
    paddingVertical: 13,
    borderRadius: 14,
    borderWidth: 1.5,
    alignItems: "center",
  },
  secondaryBtnText: {
    fontSize: 15,
    fontWeight: "600",
  },
  yolkChoiceRow: {
    flexDirection: "row",
    gap: 14,
    width: "100%",
  },
  yolkBtn: {
    flex: 1,
    borderRadius: 16,
    borderWidth: 2,
    paddingVertical: 20,
    alignItems: "center",
    gap: 6,
  },
  yolkBtnEmoji: {
    fontSize: 32,
  },
  yolkBtnTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  yolkBtnSub: {
    fontSize: 13,
  },
  completeBadge: {
    width: 90,
    height: 90,
    borderRadius: 45,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  completeEmoji: {
    fontSize: 40,
  },
  recipeCard: {
    width: "100%",
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    gap: 8,
  },
  recipeTitle: {
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 4,
  },
  recipeItem: {
    fontSize: 14,
    lineHeight: 22,
  },
  eggSettingsBox: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    gap: 8,
    marginVertical: 12,
  },
  eggSettingRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  eggSettingLabel: {
    fontSize: 13,
    fontWeight: "600",
  },
  eggSettingValue: {
    fontSize: 13,
    fontWeight: "700",
  },
});
