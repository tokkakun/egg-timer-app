/** @type {const} */
const themeColors = {
  primary: { light: '#E8793A', dark: '#F09050' },
  background: { light: '#FFFBF5', dark: '#1A1510' },
  surface: { light: '#FFF3E0', dark: '#2A1F14' },
  foreground: { light: '#2D1B00', dark: '#F5E6D0' },
  muted: { light: '#8B6914', dark: '#C4A05A' },
  border: { light: '#E8D5B0', dark: '#4A3520' },
  success: { light: '#4CAF50', dark: '#66BB6A' },
  warning: { light: '#FF9800', dark: '#FFA726' },
  error: { light: '#F44336', dark: '#EF5350' },
};

module.exports = { themeColors };
