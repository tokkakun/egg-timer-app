import React, { useEffect, useRef } from "react";
import { View, StyleSheet, Animated, Dimensions } from "react-native";
import { useColors } from "@/hooks/use-colors";

const { width: screenWidth, height: screenHeight } = Dimensions.get("window");

interface CompletionAnimationProps {
  isVisible: boolean;
  onAnimationComplete?: () => void;
}

/**
 * Particle component for confetti effect
 */
function Particle({
  delay,
  duration,
}: {
  delay: number;
  duration: number;
}) {
  const colors = useColors();
  const translateY = useRef(new Animated.Value(0)).current;
  const opacity = useRef(new Animated.Value(1)).current;
  const rotate = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.delay(delay),
      Animated.parallel([
        Animated.timing(translateY, {
          toValue: screenHeight * 0.8,
          duration: duration,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0,
          duration: duration,
          useNativeDriver: true,
        }),
        Animated.timing(rotate, {
          toValue: 360,
          duration: duration,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  }, []);

  const rotation = rotate.interpolate({
    inputRange: [0, 360],
    outputRange: ["0deg", "360deg"],
  });

  return (
    <Animated.View
      style={[
        styles.particle,
        {
          transform: [{ translateY }, { rotate: rotation }],
          opacity,
          backgroundColor: [colors.primary, colors.warning, colors.success][
            Math.floor(Math.random() * 3)
          ],
        },
      ]}
    />
  );
}

/**
 * Completion animation component showing egg completion
 */
export function CompletionAnimation({
  isVisible,
  onAnimationComplete,
}: CompletionAnimationProps) {
  const colors = useColors();
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const bgOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isVisible) {
      // Egg scale animation
      Animated.sequence([
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
        Animated.timing(bgOpacity, {
          toValue: 0.7,
          duration: 400,
          useNativeDriver: true,
        }),
      ]).start(() => {
        // Keep animation visible for 2 seconds, then trigger callback
        setTimeout(() => {
          if (onAnimationComplete) {
            Animated.parallel([
              Animated.timing(opacityAnim, {
                toValue: 0,
                duration: 300,
                useNativeDriver: true,
              }),
              Animated.timing(bgOpacity, {
                toValue: 0,
                duration: 300,
                useNativeDriver: true,
              }),
            ]).start(() => {
              onAnimationComplete();
            });
          }
        }, 2000);
      });
    } else {
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      bgOpacity.setValue(0);
    }
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
          opacity: bgOpacity,
        },
      ]}
    >
      {/* Background overlay */}
      <View style={styles.overlay} />

      {/* Animated egg */}
      <Animated.View
        style={[
          styles.eggContainer,
          {
            opacity: opacityAnim,
            transform: [
              {
                scale: scaleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.3, 1.2],
                }),
              },
            ],
          },
        ]}
      >
        <View
          style={[
            styles.egg,
            {
              borderColor: colors.primary,
              backgroundColor: colors.surface,
            },
          ]}
        >
          <View
            style={[
              styles.eggYolk,
              {
                backgroundColor: colors.warning,
              },
            ]}
          />
        </View>
      </Animated.View>

      {/* Completion text */}
      <Animated.Text
        style={[
          styles.completionText,
          {
            color: colors.foreground,
            opacity: opacityAnim,
          },
        ]}
      >
        ✓ 完成！
      </Animated.Text>

      {/* Particles */}
      {Array.from({ length: 12 }).map((_, i) => (
        <Particle
          key={i}
          delay={i * 50}
          duration={1200 + i * 100}
        />
      ))}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
  eggContainer: {
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1001,
  },
  egg: {
    width: 120,
    height: 140,
    borderRadius: 60,
    borderWidth: 4,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 12,
  },
  eggYolk: {
    width: 50,
    height: 60,
    borderRadius: 25,
  },
  completionText: {
    fontSize: 32,
    fontWeight: "700",
    marginTop: 20,
    zIndex: 1001,
  },
  particle: {
    width: 12,
    height: 12,
    borderRadius: 6,
    position: "absolute",
    top: screenHeight * 0.3,
    left: Math.random() * screenWidth,
  },
});
