# ローカルマシンでの APK ビルド手順書

このドキュメントでは、ローカルマシンで半熟卵タイマーアプリの APK ファイルをビルドする方法を説明します。

## 前提条件

以下のソフトウェアがインストール済みであることを確認してください：

- **Node.js 18 以上** — https://nodejs.org
- **npm または yarn** — Node.js に付属
- **Git** — https://git-scm.com
- **Expo アカウント** — https://expo.dev で無料登録
- **EAS CLI** — コマンドラインツール（インストール手順は下記）

## ステップ 1：プロジェクトをダウンロード

ローカルマシンにプロジェクトをクローンまたはダウンロードします。

### Git を使用する場合：

```bash
git clone <リポジトリURL> egg-timer-app
cd egg-timer-app
```

### または、ZIP ファイルをダウンロードして展開：

```bash
unzip egg-timer-app.zip
cd egg-timer-app
```

## ステップ 2：依存パッケージをインストール

プロジェクトディレクトリで以下のコマンドを実行します：

```bash
npm install
```

または、pnpm を使用する場合：

```bash
pnpm install
```

## ステップ 3：EAS CLI をインストール

グローバルに EAS CLI をインストールします：

```bash
npm install -g eas-cli
```

インストール確認：

```bash
eas --version
```

## ステップ 4：Expo アカウントにログイン

ターミナルで以下のコマンドを実行：

```bash
eas login
```

ブラウザが開き、Expo ログインページが表示されます。以下の情報でログインしてください：

- **メールアドレス** — tokkakun@gmail.com
- **パスワード** — Td9xnzAuxn

ログイン完了後、ターミナルに戻ります。

## ステップ 5：APK ビルドを実行

プロジェクトディレクトリで以下のコマンドを実行：

```bash
eas build --platform android
```

コマンド実行時に以下の質問が表示される場合があります：

- **Build type** — `apk` を選択（APK ファイルを生成）
- **Profile** — `production` を選択（デフォルト）

## ステップ 6：ビルド進捗を確認

ビルドが開始されると、以下の情報が表示されます：

```
Build started
Build ID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
Build URL: https://expo.dev/accounts/tokkakun/builds/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

ビルド URL をコピーしてブラウザで開くと、リアルタイムでビルド進捗を確認できます。

## ステップ 7：ビルド完了を待機

ビルドプロセスは通常 **5-15 分** かかります。

ビルド完了時に以下のメッセージが表示されます：

```
✓ Build finished
✓ APK download URL: https://...
```

## ステップ 8：APK ファイルをダウンロード

ビルド完了後、以下の方法でAPKファイルをダウンロードできます：

### 方法 1：ターミナルから直接ダウンロード

ビルド完了時に表示される APK ダウンロード URL をコピーして、ブラウザで開きます。

### 方法 2：Expo Web ダッシュボードからダウンロード

1. https://expo.dev にアクセス
2. ログイン（tokkakun@gmail.com / Td9xnzAuxn）
3. 「egg-timer-app」プロジェクトを選択
4. 左メニューから「Builds」をクリック
5. 完了したビルド（ステータス「Finished」）を選択
6. 「Download」ボタンをクリックして APK をダウンロード

## ステップ 9：Android デバイスにインストール

ダウンロードした APK ファイルを Android デバイスにインストールします：

### 方法 1：USB 経由で直接インストール

```bash
adb install egg-timer-app.apk
```

### 方法 2：メール経由で送信

APK ファイルをメールで自分に送信し、デバイスのメールアプリで受け取ります。

### 方法 3：クラウドストレージ経由

Google Drive、Dropbox などにアップロードして、デバイスからダウンロードします。

### 方法 4：手動でコピー

1. デバイスをコンピュータに USB 接続
2. APK ファイルをデバイスにコピー
3. デバイスのファイルマネージャーで APK を開く
4. インストール確認画面で「インストール」をタップ

## トラブルシューティング

### ログインに失敗した場合

```
Error: Invalid credentials
```

**解決方法：**
- メールアドレスとパスワードが正しいか確認
- インターネット接続を確認
- Expo アカウントが有効か確認（https://expo.dev で確認）

### ビルドが失敗した場合

```
Error: Build failed
```

**解決方法：**

1. プロジェクトのエラーをチェック：
```bash
npm run check
```

2. 依存パッケージを再インストール：
```bash
npm install
```

3. キャッシュをクリア：
```bash
eas build --platform android --clear-cache
```

4. Expo Web ダッシュボードでビルドログを確認：
   - https://expo.dev → egg-timer-app → Builds → ビルドを選択 → ログを確認

### APK ファイルが見つからない場合

**解決方法：**

1. ビルドが完了しているか確認：
```bash
eas build:list --platform android
```

2. Expo Web ダッシュボードで確認：
   - https://expo.dev → egg-timer-app → Builds

3. ビルドが「Finished」ステータスになっているか確認

### インストール時に「不明なアプリケーション」エラーが表示される場合

**解決方法：**

Android デバイスの設定で、不明なソースからのインストールを許可します：

1. 設定アプリを開く
2. 「セキュリティ」または「プライバシー」を選択
3. 「不明なアプリのインストール」を有効化
4. 再度 APK をインストール

## よくある質問

### Q: ビルドにはどのくらい時間がかかりますか？

**A:** 通常 5-15 分です。ネットワーク速度やサーバー負荷により変動します。

### Q: ビルド中にインターネット接続が切れたらどうなりますか？

**A:** ビルドが失敗します。再度ビルドを実行してください。

### Q: 複数の APK ファイルが必要な場合はどうしますか？

**A:** ビルドコマンドを複数回実行します。各ビルドで異なる APK が生成されます。

### Q: APK ファイルを他の人と共有できますか？

**A:** はい。APK ファイルは通常のファイルとして共有できます。ただし、署名キーは秘密にしてください。

### Q: APK ファイルの署名キーはどこにありますか？

**A:** EAS Build が自動的に生成・管理します。手動での操作は不要です。

## サポート

ビルドに関する問題が発生した場合は、以下のリソースを参照してください：

- **Expo 公式ドキュメント** — https://docs.expo.dev
- **EAS Build ドキュメント** — https://docs.expo.dev/build/introduction/
- **Expo コミュニティフォーラム** — https://forums.expo.dev
- **GitHub Issues** — プロジェクトリポジトリの Issues セクション

## 次のステップ

APK ファイルが正常にインストールされたら：

1. アプリを開く
2. 4 ステップのガイドに従って卵を調理
3. 加熱時間と蒸らし時間をカスタマイズ（設定タブ）
4. 音声フィードバックのオン/オフを切り替え（設定タブ）

楽しい調理を！🥚
