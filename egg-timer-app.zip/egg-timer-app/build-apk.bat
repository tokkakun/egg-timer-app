@echo off
REM APKビルド用バッチファイル
REM このバッチファイルはWindows環境で実行してください

echo.
echo ========================================
echo 半熟卵タイマー APKビルドスクリプト
echo ========================================
echo.

REM ディレクトリ確認
if not exist "app.config.ts" (
    echo エラー: このバッチファイルをプロジェクトルートディレクトリで実行してください
    pause
    exit /b 1
)

REM EAS CLIがインストールされているか確認
where eas >nul 2>nul
if %errorlevel% neq 0 (
    echo EAS CLIをインストール中...
    call npm install -g eas-cli
    if %errorlevel% neq 0 (
        echo エラー: EAS CLIのインストールに失敗しました
        pause
        exit /b 1
    )
)

REM Expoアカウントにログイン
echo.
echo Expoアカウントにログイン中...
call eas login
if %errorlevel% neq 0 (
    echo エラー: ログインに失敗しました
    pause
    exit /b 1
)

REM APKビルド実行
echo.
echo APKビルドを開始します...
echo プロセスが完了するまでお待ちください（数分〜数十分かかります）
echo.
call eas build --platform android --type apk

if %errorlevel% neq 0 (
    echo エラー: ビルドに失敗しました
    pause
    exit /b 1
)

echo.
echo ========================================
echo ビルドが完了しました！
echo ========================================
echo.
echo APKファイルは以下のURLからダウンロードできます：
echo https://expo.dev/accounts/[your-username]/projects/egg-timer-app/builds
echo.
pause
