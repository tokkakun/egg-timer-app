import { describe, it, expect } from "vitest";

// ─── Helpers (copied from app logic) ─────────────────────────────────────────

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

const STEP2_DURATION = 4 * 60;
const YOLK_RUNNY_DURATION = 3 * 60;
const YOLK_NORMAL_DURATION = 5 * 60;

// ─── Tests ────────────────────────────────────────────────────────────────────

describe("formatTime", () => {
  it("formats 0 seconds as 00:00", () => {
    expect(formatTime(0)).toBe("00:00");
  });

  it("formats 4 minutes as 04:00", () => {
    expect(formatTime(240)).toBe("04:00");
  });

  it("formats 3 minutes as 03:00", () => {
    expect(formatTime(180)).toBe("03:00");
  });

  it("formats 5 minutes as 05:00", () => {
    expect(formatTime(300)).toBe("05:00");
  });

  it("formats 1 minute 30 seconds as 01:30", () => {
    expect(formatTime(90)).toBe("01:30");
  });

  it("formats 59 seconds as 00:59", () => {
    expect(formatTime(59)).toBe("00:59");
  });
});

describe("Timer durations", () => {
  it("step2 duration is 4 minutes (240 seconds)", () => {
    expect(STEP2_DURATION).toBe(240);
  });

  it("yolk runny duration is 3 minutes (180 seconds)", () => {
    expect(YOLK_RUNNY_DURATION).toBe(180);
  });

  it("yolk normal duration is 5 minutes (300 seconds)", () => {
    expect(YOLK_NORMAL_DURATION).toBe(300);
  });
});

describe("Timer progress calculation", () => {
  it("calculates 100% progress at full time", () => {
    const remaining = STEP2_DURATION;
    const total = STEP2_DURATION;
    const progress = total > 0 ? remaining / total : 0;
    expect(progress).toBe(1);
  });

  it("calculates 50% progress at half time", () => {
    const remaining = STEP2_DURATION / 2;
    const total = STEP2_DURATION;
    const progress = total > 0 ? remaining / total : 0;
    expect(progress).toBe(0.5);
  });

  it("calculates 0% progress at zero", () => {
    const remaining = 0;
    const total = STEP2_DURATION;
    const progress = total > 0 ? remaining / total : 0;
    expect(progress).toBe(0);
  });
});

describe("Step flow logic", () => {
  it("step2 completes and transitions to yolk_choice", () => {
    type AppStep = "step1" | "step2" | "yolk_choice" | "step2b" | "step3";
    let step: AppStep = "step2";
    // Simulate timer completion for step2
    if (step === "step2") {
      step = "yolk_choice";
    }
    expect(step).toBe("yolk_choice");
  });

  it("step2b completes and transitions to step3", () => {
    type AppStep = "step1" | "step2" | "yolk_choice" | "step2b" | "step3";
    let step: AppStep = "step2b";
    // Simulate timer completion for step2b
    if (step === "step2b") {
      step = "step3";
    }
    expect(step).toBe("step3");
  });

  it("restart resets to step1", () => {
    type AppStep = "step1" | "step2" | "yolk_choice" | "step2b" | "step3";
    let step: AppStep = "step3";
    // Simulate restart
    step = "step1";
    expect(step).toBe("step1");
  });
});
