import { describe, it, expect } from "vitest";
import { secondsToMinutes, minutesToSeconds } from "../hooks/use-timer-settings";

describe("Timer Settings Helpers", () => {
  describe("secondsToMinutes", () => {
    it("converts 60 seconds to 1 minute", () => {
      expect(secondsToMinutes(60)).toBe(1);
    });

    it("converts 240 seconds to 4 minutes", () => {
      expect(secondsToMinutes(240)).toBe(4);
    });

    it("converts 180 seconds to 3 minutes", () => {
      expect(secondsToMinutes(180)).toBe(3);
    });

    it("converts 300 seconds to 5 minutes", () => {
      expect(secondsToMinutes(300)).toBe(5);
    });

    it("rounds 90 seconds to 2 minutes", () => {
      expect(secondsToMinutes(90)).toBe(2);
    });

    it("handles 0 seconds", () => {
      expect(secondsToMinutes(0)).toBe(0);
    });
  });

  describe("minutesToSeconds", () => {
    it("converts 1 minute to 60 seconds", () => {
      expect(minutesToSeconds(1)).toBe(60);
    });

    it("converts 4 minutes to 240 seconds", () => {
      expect(minutesToSeconds(4)).toBe(240);
    });

    it("converts 3 minutes to 180 seconds", () => {
      expect(minutesToSeconds(3)).toBe(180);
    });

    it("converts 5 minutes to 300 seconds", () => {
      expect(minutesToSeconds(5)).toBe(300);
    });

    it("handles 0 minutes", () => {
      expect(minutesToSeconds(0)).toBe(0);
    });

    it("converts 10 minutes to 600 seconds", () => {
      expect(minutesToSeconds(10)).toBe(600);
    });
  });

  describe("Conversion round-trip", () => {
    it("converts seconds to minutes and back", () => {
      const original = 240;
      const minutes = secondsToMinutes(original);
      const converted = minutesToSeconds(minutes);
      expect(converted).toBe(original);
    });

    it("handles various durations", () => {
      const durations = [60, 120, 180, 240, 300, 360, 600];
      durations.forEach((duration) => {
        const minutes = secondsToMinutes(duration);
        const converted = minutesToSeconds(minutes);
        expect(converted).toBe(duration);
      });
    });
  });

  describe("Settings validation", () => {
    it("enforces minimum duration of 1 minute (60 seconds)", () => {
      expect(minutesToSeconds(1)).toBe(60);
      expect(secondsToMinutes(60)).toBe(1);
    });

    it("enforces maximum duration of 10 minutes (600 seconds)", () => {
      expect(minutesToSeconds(10)).toBe(600);
      expect(secondsToMinutes(600)).toBe(10);
    });
  });
});
