/**
 * Egg cooking time calculator based on size and temperature
 * Based on the 1cm water steaming method (鍋底から1cmの水で蒸す方法)
 */

export type EggSize = "M" | "L";
export type EggTemperature = "room" | "cold"; // room temperature or refrigerated

export interface CookingTime {
  heatDuration: number; // in seconds
  runnyDuration: number; // in seconds (とろとろ)
  normalDuration: number; // in seconds (普通)
}

/**
 * Cooking time presets for different egg sizes and temperatures
 * Times are based on the 1cm water steaming method
 *
 * M size (50-60g): Standard medium egg
 * L size (60-70g): Large egg
 *
 * Room temperature: ~20°C
 * Refrigerated: ~4°C
 *
 * Heating phase: Bring water to boil
 * Steaming phase (runny): Soft boiled (とろとろ) - ~3 minutes
 * Steaming phase (normal): Medium boiled (普通) - ~5 minutes
 */
const COOKING_PRESETS: Record<EggSize, Record<EggTemperature, CookingTime>> = {
  M: {
    room: {
      heatDuration: 4 * 60, // 4 minutes to boil
      runnyDuration: 3 * 60, // 3 minutes for soft boiled
      normalDuration: 5 * 60, // 5 minutes for medium boiled
    },
    cold: {
      heatDuration: 4.5 * 60, // 4.5 minutes (slightly longer due to cold eggs)
      runnyDuration: 3.5 * 60, // 3.5 minutes for soft boiled
      normalDuration: 5.5 * 60, // 5.5 minutes for medium boiled
    },
  },
  L: {
    room: {
      heatDuration: 4.5 * 60, // 4.5 minutes to boil (larger eggs take longer)
      runnyDuration: 3.5 * 60, // 3.5 minutes for soft boiled
      normalDuration: 5.5 * 60, // 5.5 minutes for medium boiled
    },
    cold: {
      heatDuration: 5 * 60, // 5 minutes (larger + cold)
      runnyDuration: 4 * 60, // 4 minutes for soft boiled
      normalDuration: 6 * 60, // 6 minutes for medium boiled
    },
  },
};

/**
 * Get cooking time based on egg size and temperature
 */
export function getCookingTime(size: EggSize, temperature: EggTemperature): CookingTime {
  return COOKING_PRESETS[size][temperature];
}

/**
 * Get all available egg sizes
 */
export function getAvailableSizes(): EggSize[] {
  return ["M", "L"];
}

/**
 * Get all available temperatures
 */
export function getAvailableTemperatures(): EggTemperature[] {
  return ["room", "cold"];
}

/**
 * Get human-readable label for egg size
 */
export function getSizeLabel(size: EggSize): string {
  const labels: Record<EggSize, string> = {
    M: "M サイズ (50-60g)",
    L: "L サイズ (60-70g)",
  };
  return labels[size];
}

/**
 * Get human-readable label for temperature
 */
export function getTemperatureLabel(temperature: EggTemperature): string {
  const labels: Record<EggTemperature, string> = {
    room: "常温 (~20°C)",
    cold: "冷蔵 (~4°C)",
  };
  return labels[temperature];
}

/**
 * Format cooking time for display
 */
export function formatCookingTime(seconds: number): string {
  const minutes = Math.round(seconds / 60);
  return `${minutes}分`;
}

/**
 * Get description for cooking result
 */
export function getCookingResultDescription(type: "runny" | "normal"): string {
  const descriptions: Record<string, string> = {
    runny: "とろとろ（黄身が半熟）",
    normal: "普通（黄身がやや固い）",
  };
  return descriptions[type];
}
