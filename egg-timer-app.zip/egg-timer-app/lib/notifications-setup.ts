import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

/**
 * Initialize notification settings
 * Must be called once at app startup
 */
export async function initializeNotifications() {
  // Set notification handler for foreground notifications
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });

  // Android: Create notification channel
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#E8793A",
      sound: "default",
      enableVibrate: true,
    });
  }
}

/**
 * Request notification permissions
 */
export async function requestNotificationPermissions() {
  const { status: existingStatus } =
    await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  return finalStatus === "granted";
}

/**
 * Schedule a local notification
 */
export async function scheduleNotification(
  title: string,
  body: string,
  delaySeconds: number = 0
) {
  try {
    const trigger = delaySeconds > 0 ? { seconds: delaySeconds } : null;
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: "default",
        badge: 1,
        data: {
          timestamp: new Date().toISOString(),
        },
      },
      trigger: trigger as any,
    });
  } catch (error) {
    console.error("Failed to schedule notification:", error);
  }
}

/**
 * Send an immediate notification
 */
export async function sendImmediateNotification(
  title: string,
  body: string
) {
  return scheduleNotification(title, body, 0);
}
