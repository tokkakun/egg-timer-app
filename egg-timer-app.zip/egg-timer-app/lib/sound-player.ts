import { Platform, Vibration } from "react-native";

/**
 * Initialize audio mode for silent mode playback
 */
export async function initializeAudioMode() {
  try {
    if (Platform.OS !== "web") {
      const { setAudioModeAsync } = require("expo-audio");
      await setAudioModeAsync({
        playsInSilentMode: true,
      });
    }
  } catch (error) {
    console.error("Failed to set audio mode:", error);
  }
}

/**
 * Play a simple beep sound
 * Uses Web Audio API for web and Vibration API for native platforms
 */
export function playBeepSound() {
  try {
    if (Platform.OS === "web") {
      playWebBeep();
    } else {
      // Use vibration pattern as fallback for native platforms
      playVibrationBeep();
    }
  } catch (error) {
    console.error("Failed to play beep sound:", error);
  }
}

/**
 * Play tap sound for button interactions
 */
export function playTapSound() {
  try {
    if (Platform.OS === "web") {
      playWebTap();
    } else {
      // Use vibration pattern as fallback for native platforms
      playVibrationTap();
    }
  } catch (error) {
    console.error("Failed to play tap sound:", error);
  }
}

/**
 * Play beep using Web Audio API
 */
function playWebBeep() {
  try {
    const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const audioContext = new AudioContext();

    // Play 3 beeps
    for (let beepIndex = 0; beepIndex < 3; beepIndex++) {
      const startTime = audioContext.currentTime + beepIndex * 0.3;
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800; // 800 Hz tone
      oscillator.type = "sine";

      gainNode.gain.setValueAtTime(0.3, startTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.1);

      oscillator.start(startTime);
      oscillator.stop(startTime + 0.1);
    }
  } catch (error) {
    console.error("Failed to play web beep:", error);
  }
}

/**
 * Play tap sound using Web Audio API
 */
function playWebTap() {
  try {
    const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const audioContext = new AudioContext();

    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 1000; // 1000 Hz tone for tap
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.05);
  } catch (error) {
    console.error("Failed to play web tap sound:", error);
  }
}

/**
 * Play vibration pattern for beep on native platforms
 */
function playVibrationBeep() {
  try {
    if (Vibration) {
      // Pattern: [delay, vibrate, delay, vibrate, delay, vibrate]
      Vibration.vibrate([0, 100, 100, 100, 100, 100], false);
    }
  } catch (error) {
    console.error("Failed to play vibration beep:", error);
  }
}

/**
 * Play vibration pattern for tap on native platforms
 */
function playVibrationTap() {
  try {
    if (Vibration) {
      Vibration.vibrate(50, false);
    }
  } catch (error) {
    console.error("Failed to play vibration tap:", error);
  }
}
