import { Platform, Vibration } from "react-native";

export type AlarmSoundType = "beep" | "chime" | "bell" | "ding" | "notification";

export interface AlarmSound {
  id: AlarmSoundType;
  name: string;
  description: string;
  emoji: string;
}

export const ALARM_SOUNDS: Record<AlarmSoundType, AlarmSound> = {
  beep: {
    id: "beep",
    name: "ビープ",
    description: "シンプルなビープ音（3回）",
    emoji: "📢",
  },
  chime: {
    id: "chime",
    name: "チャイム",
    description: "優しいチャイム音",
    emoji: "🔔",
  },
  bell: {
    id: "bell",
    name: "ベル",
    description: "クリアなベル音",
    emoji: "🛎️",
  },
  ding: {
    id: "ding",
    name: "ディング",
    description: "軽快なディング音",
    emoji: "✨",
  },
  notification: {
    id: "notification",
    name: "通知音",
    description: "スマートフォンの通知音",
    emoji: "📳",
  },
};

/**
 * Play alarm sound based on selected type
 */
export function playAlarmSound(soundType: AlarmSoundType) {
  try {
    if (Platform.OS === "web") {
      playWebAlarmSound(soundType);
    } else {
      playNativeAlarmSound(soundType);
    }
  } catch (error) {
    console.error("Failed to play alarm sound:", error);
  }
}

/**
 * Play alarm sound using Web Audio API
 */
function playWebAlarmSound(soundType: AlarmSoundType) {
  try {
    const AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const audioContext = new AudioContext();

    switch (soundType) {
      case "beep":
        playWebBeep(audioContext);
        break;
      case "chime":
        playWebChime(audioContext);
        break;
      case "bell":
        playWebBell(audioContext);
        break;
      case "ding":
        playWebDing(audioContext);
        break;
      case "notification":
        playWebNotification(audioContext);
        break;
    }
  } catch (error) {
    console.error("Failed to play web alarm sound:", error);
  }
}

/**
 * Play beep sound (3 short beeps)
 */
function playWebBeep(audioContext: AudioContext) {
  for (let beepIndex = 0; beepIndex < 3; beepIndex++) {
    const startTime = audioContext.currentTime + beepIndex * 0.3;
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 800; // 800 Hz
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.3, startTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + 0.1);

    oscillator.start(startTime);
    oscillator.stop(startTime + 0.1);
  }
}

/**
 * Play chime sound (descending notes)
 */
function playWebChime(audioContext: AudioContext) {
  const frequencies = [800, 700, 600]; // Descending frequencies
  const duration = 0.15;
  const gap = 0.1;

  frequencies.forEach((freq, index) => {
    const startTime = audioContext.currentTime + index * (duration + gap);
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = freq;
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.25, startTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

    oscillator.start(startTime);
    oscillator.stop(startTime + duration);
  });
}

/**
 * Play bell sound (ascending then descending)
 */
function playWebBell(audioContext: AudioContext) {
  const frequencies = [600, 750, 900, 750, 600]; // Bell-like pattern
  const duration = 0.12;
  const gap = 0.08;

  frequencies.forEach((freq, index) => {
    const startTime = audioContext.currentTime + index * (duration + gap);
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = freq;
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.2, startTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

    oscillator.start(startTime);
    oscillator.stop(startTime + duration);
  });
}

/**
 * Play ding sound (single high note)
 */
function playWebDing(audioContext: AudioContext) {
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  oscillator.frequency.value = 1000; // 1000 Hz
  oscillator.type = "sine";

  gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);

  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 0.2);
}

/**
 * Play notification sound (two-tone)
 */
function playWebNotification(audioContext: AudioContext) {
  const tones = [
    { freq: 700, duration: 0.1, gap: 0.05 },
    { freq: 900, duration: 0.1, gap: 0 },
  ];

  let currentTime = audioContext.currentTime;

  tones.forEach((tone) => {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = tone.freq;
    oscillator.type = "sine";

    gainNode.gain.setValueAtTime(0.25, currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, currentTime + tone.duration);

    oscillator.start(currentTime);
    oscillator.stop(currentTime + tone.duration);

    currentTime += tone.duration + tone.gap;
  });
}

/**
 * Play alarm sound on native platforms using vibration patterns
 */
function playNativeAlarmSound(soundType: AlarmSoundType) {
  try {
    if (!Vibration) return;

    switch (soundType) {
      case "beep":
        // Pattern: [delay, vibrate, delay, vibrate, delay, vibrate]
        Vibration.vibrate([0, 100, 100, 100, 100, 100], false);
        break;
      case "chime":
        // Pattern: descending vibration intensity
        Vibration.vibrate([0, 150, 100, 120, 80, 100], false);
        break;
      case "bell":
        // Pattern: bell-like vibration
        Vibration.vibrate([0, 80, 60, 100, 60, 80, 60, 100], false);
        break;
      case "ding":
        // Pattern: single strong vibration
        Vibration.vibrate([0, 200], false);
        break;
      case "notification":
        // Pattern: two-tone vibration
        Vibration.vibrate([0, 100, 100, 150], false);
        break;
    }
  } catch (error) {
    console.error("Failed to play native alarm sound:", error);
  }
}

/**
 * Get all available alarm sounds
 */
export function getAvailableAlarmSounds(): AlarmSound[] {
  return Object.values(ALARM_SOUNDS);
}

/**
 * Get alarm sound by ID
 */
export function getAlarmSoundById(id: AlarmSoundType): AlarmSound | undefined {
  return ALARM_SOUNDS[id];
}
