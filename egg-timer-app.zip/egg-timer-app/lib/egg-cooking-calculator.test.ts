import { describe, it, expect } from "vitest";
import {
  getCookingTime,
  getAvailableSizes,
  getAvailableTemperatures,
  getSizeLabel,
  getTemperatureLabel,
  formatCookingTime,
  getCookingResultDescription,
  EggSize,
  EggTemperature,
} from "./egg-cooking-calculator";

describe("egg-cooking-calculator", () => {
  describe("getCookingTime", () => {
    it("should return correct cooking time for M size room temperature", () => {
      const time = getCookingTime("M", "room");
      expect(time.heatDuration).toBe(4 * 60); // 4 minutes
      expect(time.runnyDuration).toBe(3 * 60); // 3 minutes
      expect(time.normalDuration).toBe(5 * 60); // 5 minutes
    });

    it("should return correct cooking time for M size cold temperature", () => {
      const time = getCookingTime("M", "cold");
      expect(time.heatDuration).toBe(4.5 * 60); // 4.5 minutes
      expect(time.runnyDuration).toBe(3.5 * 60); // 3.5 minutes
      expect(time.normalDuration).toBe(5.5 * 60); // 5.5 minutes
    });

    it("should return correct cooking time for L size room temperature", () => {
      const time = getCookingTime("L", "room");
      expect(time.heatDuration).toBe(4.5 * 60); // 4.5 minutes
      expect(time.runnyDuration).toBe(3.5 * 60); // 3.5 minutes
      expect(time.normalDuration).toBe(5.5 * 60); // 5.5 minutes
    });

    it("should return correct cooking time for L size cold temperature", () => {
      const time = getCookingTime("L", "cold");
      expect(time.heatDuration).toBe(5 * 60); // 5 minutes
      expect(time.runnyDuration).toBe(4 * 60); // 4 minutes
      expect(time.normalDuration).toBe(6 * 60); // 6 minutes
    });

    it("cold eggs should have longer cooking time than room temperature", () => {
      const roomTime = getCookingTime("M", "room");
      const coldTime = getCookingTime("M", "cold");
      expect(coldTime.heatDuration).toBeGreaterThan(roomTime.heatDuration);
      expect(coldTime.runnyDuration).toBeGreaterThan(roomTime.runnyDuration);
      expect(coldTime.normalDuration).toBeGreaterThan(roomTime.normalDuration);
    });

    it("large eggs should have longer cooking time than medium eggs", () => {
      const mediumTime = getCookingTime("M", "room");
      const largeTime = getCookingTime("L", "room");
      expect(largeTime.heatDuration).toBeGreaterThanOrEqual(mediumTime.heatDuration);
      expect(largeTime.runnyDuration).toBeGreaterThanOrEqual(mediumTime.runnyDuration);
      expect(largeTime.normalDuration).toBeGreaterThanOrEqual(mediumTime.normalDuration);
    });
  });

  describe("getAvailableSizes", () => {
    it("should return array of available sizes", () => {
      const sizes = getAvailableSizes();
      expect(sizes).toContain("M");
      expect(sizes).toContain("L");
      expect(sizes.length).toBe(2);
    });
  });

  describe("getAvailableTemperatures", () => {
    it("should return array of available temperatures", () => {
      const temps = getAvailableTemperatures();
      expect(temps).toContain("room");
      expect(temps).toContain("cold");
      expect(temps.length).toBe(2);
    });
  });

  describe("getSizeLabel", () => {
    it("should return correct label for M size", () => {
      const label = getSizeLabel("M");
      expect(label).toContain("M");
      expect(label).toContain("50-60g");
    });

    it("should return correct label for L size", () => {
      const label = getSizeLabel("L");
      expect(label).toContain("L");
      expect(label).toContain("60-70g");
    });
  });

  describe("getTemperatureLabel", () => {
    it("should return correct label for room temperature", () => {
      const label = getTemperatureLabel("room");
      expect(label).toContain("常温");
      expect(label).toContain("20°C");
    });

    it("should return correct label for cold temperature", () => {
      const label = getTemperatureLabel("cold");
      expect(label).toContain("冷蔵");
      expect(label).toContain("4°C");
    });
  });

  describe("formatCookingTime", () => {
    it("should format seconds to minutes correctly", () => {
      expect(formatCookingTime(60)).toBe("1分");
      expect(formatCookingTime(180)).toBe("3分");
      expect(formatCookingTime(300)).toBe("5分");
    });

    it("should round to nearest minute", () => {
      expect(formatCookingTime(90)).toBe("2分");
      expect(formatCookingTime(270)).toBe("5分"); // 270 seconds = 4.5 minutes, rounds to 5
    });
  });

  describe("getCookingResultDescription", () => {
    it("should return correct description for runny", () => {
      const desc = getCookingResultDescription("runny");
      expect(desc).toContain("とろとろ");
      expect(desc).toContain("半熟");
    });

    it("should return correct description for normal", () => {
      const desc = getCookingResultDescription("normal");
      expect(desc).toContain("普通");
      expect(desc).toContain("やや固い");
    });
  });
});
